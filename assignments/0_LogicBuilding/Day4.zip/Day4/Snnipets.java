



class Snnipets{
public static void main(String args[]){

for(int i = 0 ; i<5 ; i++){
		if(false){
			//System.out.println("inside for loop");
			break;
		}
	System.out.println("inside for loop");
	}
	
	System.out.println("outside for loop");
}


}

